/**
 * Icon Generator Script
 * Run this in a browser console or Node.js to generate PNG icons from the canvas
 * 
 * For production, replace these with actual PNG files or use a tool like:
 * - https://convertio.co/svg-png/
 * - Figma export
 * - ImageMagick: `convert icon.svg icon.png`
 */

function generateIcon(size) {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  
  // Background gradient
  const gradient = ctx.createLinearGradient(0, 0, size, size);
  gradient.addColorStop(0, '#0077b5');
  gradient.addColorStop(1, '#00a0dc');
  
  // Rounded rectangle
  const radius = size * 0.15;
  ctx.beginPath();
  ctx.roundRect(0, 0, size, size, radius);
  ctx.fillStyle = gradient;
  ctx.fill();
  
  // Sparkle emoji
  ctx.font = `${size * 0.5}px Arial`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('✨', size / 2, size / 2);
  
  return canvas.toDataURL('image/png');
}

// Generate all sizes
const sizes = [16, 32, 48, 128];
sizes.forEach(size => {
  console.log(`Icon ${size}x${size}:`, generateIcon(size));
});
