/**
 * LinkedIn Engage AI - Shared Utilities
 */

export const ENGAGEMENT_TONES = {
  sell: {
    id: 'sell',
    label: 'Sell',
    icon: '💼',
    description: 'Value-driven pitch, subtle and non-pushy'
  },
  lighthearted: {
    id: 'lighthearted',
    label: 'Lighthearted',
    icon: '😊',
    description: 'Friendly, warm, humorous, short'
  },
  reply_comment: {
    id: 'reply_comment',
    label: 'Reply comment',
    icon: '💬',
    description: 'Simple acknowledgment and direct response'
  },
  book_meeting: {
    id: 'book_meeting',
    label: 'Book meeting',
    icon: '📅',
    description: 'Guide toward a call/meeting with clear CTA'
  },
  dm: {
    id: 'dm',
    label: 'DM',
    icon: '✉️',
    description: 'Invite private message continuation'
  },
  repost: {
    id: 'repost',
    label: 'Repost',
    icon: '🔄',
    description: 'Generate text suitable for repost caption'
  },
  support: {
    id: 'support',
    label: 'Support',
    icon: '👏',
    description: 'Encouraging, positive reinforcement'
  },
  add_opinion: {
    id: 'add_opinion',
    label: 'Add opinion',
    icon: '💡',
    description: 'Share thoughtful perspective or insights'
  },
  ask_question: {
    id: 'ask_question',
    label: 'Ask question',
    icon: '❓',
    description: 'Open-ended, conversation-starter question'
  },
  answer_question: {
    id: 'answer_question',
    label: 'Answer question',
    icon: '✅',
    description: 'Clear, concise answer to the post\'s question'
  },
  share_resources: {
    id: 'share_resources',
    label: 'Share resources',
    icon: '📚',
    description: 'Recommend useful links, tools, or guides'
  },
  make_intro: {
    id: 'make_intro',
    label: 'Make an intro',
    icon: '🤝',
    description: 'Craft an intro message between two parties'
  },
  custom: {
    id: 'custom',
    label: '+',
    icon: '➕',
    description: 'Enter custom tone or style'
  }
};

export const DEFAULT_SETTINGS = {
  preferences: {
    defaultTone: '',
    responseLength: 'medium',
    includeEmojis: true,
    includeHashtags: false
  },
  advanced: {
    model: 'gpt-4o-mini',
    temperature: 0.8
  }
};

/**
 * Track usage statistics
 */
export async function trackUsage(action, tone = null) {
  try {
    const result = await chrome.storage.local.get(['stats']);
    const stats = result.stats || { generated: 0, inserted: 0, tones: {} };

    if (action === 'generate') {
      stats.generated++;
      if (tone) {
        stats.tones[tone] = (stats.tones[tone] || 0) + 1;
      }
    } else if (action === 'insert') {
      stats.inserted++;
    }

    await chrome.storage.local.set({ stats });
  } catch (error) {
    console.error('Failed to track usage:', error);
  }
}

/**
 * Build user profile string for AI context
 */
export async function getUserProfileContext() {
  try {
    const result = await chrome.storage.sync.get(['user_profile']);
    if (!result.user_profile) return null;

    const profile = result.user_profile;
    const parts = [];

    if (profile.name) parts.push(`Name: ${profile.name}`);
    if (profile.title) parts.push(`Title: ${profile.title}`);
    if (profile.company) parts.push(`Company: ${profile.company}`);
    if (profile.industry) parts.push(`Industry: ${profile.industry}`);
    if (profile.bio) parts.push(`Bio: ${profile.bio}`);

    return parts.length > 0 ? parts.join('\n') : null;
  } catch (error) {
    console.error('Failed to get user profile:', error);
    return null;
  }
}

/**
 * Get extension settings
 */
export async function getSettings() {
  try {
    const result = await chrome.storage.sync.get(['preferences', 'advanced_settings']);
    return {
      preferences: { ...DEFAULT_SETTINGS.preferences, ...result.preferences },
      advanced: { ...DEFAULT_SETTINGS.advanced, ...result.advanced_settings }
    };
  } catch (error) {
    console.error('Failed to get settings:', error);
    return DEFAULT_SETTINGS;
  }
}
