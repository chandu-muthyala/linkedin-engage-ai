/**
 * LinkedIn Engage AI - Popup Script
 */

document.addEventListener('DOMContentLoaded', () => {
  initPopup();
});

async function initPopup() {
  await checkApiKeyStatus();
  await loadStats();
  setupEventListeners();
}

async function checkApiKeyStatus() {
  const statusIndicator = document.getElementById('statusIndicator');
  const statusDot = statusIndicator.querySelector('.status-dot');
  const statusText = statusIndicator.querySelector('.status-text');
  const apiKeyWarning = document.getElementById('apiKeyWarning');

  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_API_KEY_STATUS' });
    
    if (response.hasApiKey) {
      statusDot.classList.add('active');
      statusDot.classList.remove('error');
      statusText.textContent = 'Ready to engage!';
      apiKeyWarning.style.display = 'none';
    } else {
      statusDot.classList.add('error');
      statusDot.classList.remove('active');
      statusText.textContent = 'API key not configured';
      apiKeyWarning.style.display = 'block';
    }
  } catch (error) {
    statusDot.classList.add('error');
    statusText.textContent = 'Error checking status';
    console.error('Status check error:', error);
  }
}

async function loadStats() {
  try {
    const result = await chrome.storage.local.get(['stats']);
    const stats = result.stats || { generated: 0, inserted: 0, tones: {} };

    document.getElementById('totalGenerated').textContent = stats.generated || 0;
    document.getElementById('totalInserted').textContent = stats.inserted || 0;

    // Find favorite tone
    if (stats.tones && Object.keys(stats.tones).length > 0) {
      const favoriteTone = Object.entries(stats.tones)
        .sort((a, b) => b[1] - a[1])[0][0];
      document.getElementById('favoriteTone').textContent = formatToneName(favoriteTone);
    }
  } catch (error) {
    console.error('Failed to load stats:', error);
  }
}

function formatToneName(tone) {
  const toneNames = {
    'sell': 'Sell',
    'lighthearted': 'Light',
    'reply_comment': 'Reply',
    'book_meeting': 'Meet',
    'dm': 'DM',
    'repost': 'Repost',
    'support': 'Support',
    'add_opinion': 'Opinion',
    'ask_question': 'Ask',
    'answer_question': 'Answer',
    'share_resources': 'Share',
    'make_intro': 'Intro',
    'custom': 'Custom'
  };
  return toneNames[tone] || tone;
}

function setupEventListeners() {
  // Open LinkedIn button
  document.getElementById('openLinkedIn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.linkedin.com/feed/' });
  });

  // Open Options button
  document.getElementById('openOptions').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // Setup API Key button
  document.getElementById('setupApiKey')?.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // Help link
  document.getElementById('helpLink').addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'https://github.com/linkedin-engage-ai/help' });
  });

  // Feedback link
  document.getElementById('feedbackLink').addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'https://github.com/linkedin-engage-ai/feedback' });
  });
}
