# LinkedIn Engage AI

An AI-powered Chrome extension that helps you engage with LinkedIn posts by generating personalized, context-aware responses in various tones.

![LinkedIn Engage AI](assets/icons/icon128.svg)

## ✨ Features

- **13 Engagement Tones**: Sell, Lighthearted, Reply Comment, Book Meeting, DM, Repost, Support, Add Opinion, Ask Question, Answer Question, Share Resources, Make an Intro, and Custom
- **AI-Powered Responses**: Generates 3 unique, contextually relevant responses per request
- **One-Click Insert**: Instantly insert generated responses into LinkedIn comment boxes
- **Customizable Persona**: Set your professional profile to personalize responses
- **Privacy-First**: All data stored locally in your browser

## 🚀 Installation

### From Source (Development)

1. **Clone or download** this repository
2. **Generate Icons** (required before loading):
   - Open `scripts/generate-icons.html` in a browser
   - Download all 4 PNG icons (16, 32, 48, 128)
   - Save them to `assets/icons/` folder
3. **Load the extension** in Chrome:
   - Go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)
   - Click "Load unpacked"
   - Select the `linkedin_engage` folder

### Configuration

1. Click the extension icon and go to **Settings**
2. Enter your **OpenAI API key**
   - Get one from [OpenAI Dashboard](https://platform.openai.com/api-keys)
3. (Optional) Set up your **Professional Profile** for personalized responses
4. (Optional) Customize **Preferences** and **Advanced Settings**

## 📖 How to Use

1. **Navigate to LinkedIn** and find a post you want to engage with
2. **Click the "✨ Engage AI"** button that appears near each post
3. **Select an engagement tone** from the popup panel:

| Tone | Description |
|------|-------------|
| 💼 Sell | Value-driven pitch, subtle and non-pushy |
| 😊 Lighthearted | Friendly, warm, humorous, short |
| 💬 Reply comment | Simple acknowledgment and direct response |
| 📅 Book meeting | Guide toward a call/meeting with clear CTA |
| ✉️ DM | Invite private message continuation |
| 🔄 Repost | Generate caption for your own repost |
| 👏 Support | Encouraging, positive reinforcement |
| 💡 Add opinion | Share thoughtful perspective or insights |
| ❓ Ask question | Open-ended, conversation-starter question |
| ✅ Answer question | Clear, concise answer to the post's question |
| 📚 Share resources | Recommend useful links, tools, or guides |
| 🤝 Make an intro | Craft an intro message between two parties |
| ➕ Custom | Enter your own custom tone or style |

4. **Review** the generated responses (1 primary + 2 alternatives)
5. **Copy** to clipboard or **Insert** directly into the comment box

## 🏗️ Project Structure

```
linkedin_engage/
├── manifest.json              # Extension manifest
├── src/
│   ├── background/
│   │   └── background.js      # Service worker, OpenAI API calls
│   ├── content/
│   │   └── content.js         # Injects UI into LinkedIn pages
│   ├── popup/
│   │   ├── popup.html         # Extension popup
│   │   ├── popup.css          # Popup styles
│   │   └── popup.js           # Popup logic
│   ├── options/
│   │   ├── options.html       # Settings page
│   │   ├── options.css        # Settings styles
│   │   └── options.js         # Settings logic
│   └── styles/
│       └── content.css        # Injected UI styles
├── assets/
│   └── icons/                 # Extension icons
└── scripts/
    └── generate-icons.html    # Icon generator tool
```

## ⚙️ Technical Details

### API Integration

The extension uses OpenAI's Chat Completions API with:
- **Default Model**: GPT-4o Mini (configurable)
- **Temperature**: 0.8 (configurable)
- **Output**: JSON with primary response + 2 alternatives

### Data Storage

- **API Key**: Stored in `chrome.storage.sync` (encrypted by Chrome)
- **Settings**: Stored in `chrome.storage.sync`
- **Usage Stats**: Stored in `chrome.storage.local`

### Permissions

- `activeTab`: Access current tab content
- `storage`: Store settings and API key
- `host_permissions`: LinkedIn and OpenAI API domains

## 🔒 Privacy

- **No data collection**: Your data never leaves your browser
- **API calls**: Made directly from your browser to OpenAI
- **Local storage**: All settings stored locally
- **No tracking**: No analytics or telemetry

## 🐛 Troubleshooting

### "API key not configured"
1. Go to Settings (⚙️ in popup)
2. Enter your OpenAI API key
3. Click "Test Connection" to verify
4. Click "Save API Key"

### Button doesn't appear on posts
- Refresh the LinkedIn page
- Check that the extension is enabled in `chrome://extensions/`
- Some post types may not be fully supported

### Response generation fails
- Check your API key is valid
- Ensure you have API credits in your OpenAI account
- Try selecting a different AI model in Advanced Settings

## 🤝 Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

MIT License - feel free to use and modify as needed.

## 🙏 Acknowledgments

- Built with OpenAI's GPT models
- Designed for the LinkedIn community
- Inspired by the need for authentic, meaningful engagement

---

**Disclaimer**: This extension is not affiliated with or endorsed by LinkedIn or OpenAI. Use responsibly and in accordance with LinkedIn's Terms of Service.
