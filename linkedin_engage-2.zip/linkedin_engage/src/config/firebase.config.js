/**
 * LinkedIn Engage AI - Firebase Configuration
 * 
 * SETUP INSTRUCTIONS:
 * 1. Go to https://console.firebase.google.com/
 * 2. Create a new project or select existing one
 * 3. Go to Project Settings > General
 * 4. Scroll down to "Your apps" and click "Add app" > Web
 * 5. Copy the firebaseConfig values and paste them below
 * 6. Go to Firestore Database and create a database
 * 7. Set up security rules (see below)
 */

export const firebaseConfig = {
  apiKey: "AIzaSyB3grbdy16Z_Tqr7m4PCKyHjK1jzjGnKnc",
  authDomain: "linkedinengageai-d869c.firebaseapp.com",
  projectId: "linkedinengageai-d869c",
  storageBucket: "linkedinengageai-d869c.firebasestorage.app",
  messagingSenderId: "454912095508",
  appId: "1:454912095508:web:957d50197ef942f20b7e01",
  measurementId: "G-N22S0ZZMXF",
};

/**
 * Firestore Security Rules (paste in Firebase Console > Firestore > Rules):
 * 
 * rules_version = '2';
 * service cloud.firestore {
 *   match /databases/{database}/documents {
 *     match /users/{userId} {
 *       allow read, write: if request.auth != null && request.auth.uid == userId;
 *     }
 *     match /users/{userId}/sessions/{sessionId} {
 *       allow read, write: if request.auth != null && request.auth.uid == userId;
 *     }
 *   }
 * }
 */

export default firebaseConfig;
