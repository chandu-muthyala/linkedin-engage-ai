/**
 * LinkedIn Engage AI - Options Page Script
 */

document.addEventListener('DOMContentLoaded', () => {
  initOptions();
});

async function initOptions() {
  await loadSettings();
  setupEventListeners();
}

async function loadSettings() {
  try {
    // Load API key status
    const apiKeyResult = await chrome.storage.sync.get(['openai_api_key']);
    if (apiKeyResult.openai_api_key) {
      document.getElementById('apiKey').value = '••••••••••••••••••••••••••••••••';
      document.getElementById('apiKey').dataset.hasKey = 'true';
    }

    // Load user profile
    const profileResult = await chrome.storage.sync.get(['user_profile']);
    if (profileResult.user_profile) {
      const profile = profileResult.user_profile;
      document.getElementById('userName').value = profile.name || '';
      document.getElementById('userTitle').value = profile.title || '';
      document.getElementById('userCompany').value = profile.company || '';
      document.getElementById('userIndustry').value = profile.industry || '';
      document.getElementById('userBio').value = profile.bio || '';
    }

    // Load preferences
    const prefsResult = await chrome.storage.sync.get(['preferences']);
    if (prefsResult.preferences) {
      const prefs = prefsResult.preferences;
      document.getElementById('defaultTone').value = prefs.defaultTone || '';
      document.getElementById('responseLength').value = prefs.responseLength || 'medium';
      document.getElementById('includeEmojis').checked = prefs.includeEmojis !== false;
      document.getElementById('includeHashtags').checked = prefs.includeHashtags === true;
    }

    // Load advanced settings
    const advancedResult = await chrome.storage.sync.get(['advanced_settings']);
    if (advancedResult.advanced_settings) {
      const advanced = advancedResult.advanced_settings;
      document.getElementById('aiModel').value = advanced.model || 'gpt-4o-mini';
      const tempValue = Math.round((advanced.temperature || 0.8) * 100);
      document.getElementById('temperature').value = tempValue;
      document.getElementById('temperatureValue').textContent = (tempValue / 100).toFixed(1);
    }
  } catch (error) {
    console.error('Failed to load settings:', error);
  }
}

function setupEventListeners() {
  // API Key Section
  document.getElementById('toggleApiKey').addEventListener('click', toggleApiKeyVisibility);
  document.getElementById('testApiKey').addEventListener('click', testApiKey);
  document.getElementById('saveApiKey').addEventListener('click', saveApiKey);

  // Profile Section
  document.getElementById('saveProfile').addEventListener('click', saveProfile);

  // Preferences Section
  document.getElementById('savePreferences').addEventListener('click', savePreferences);

  // Advanced Section
  document.getElementById('temperature').addEventListener('input', updateTemperatureDisplay);
  document.getElementById('saveAdvanced').addEventListener('click', saveAdvanced);

  // Data Section
  document.getElementById('exportData').addEventListener('click', exportData);
  document.getElementById('clearData').addEventListener('click', clearData);

  // Clear placeholder when user starts typing in API key field
  document.getElementById('apiKey').addEventListener('focus', (e) => {
    if (e.target.dataset.hasKey === 'true') {
      e.target.value = '';
      e.target.type = 'password';
    }
  });
}

function toggleApiKeyVisibility() {
  const input = document.getElementById('apiKey');
  const btn = document.getElementById('toggleApiKey');
  
  if (input.type === 'password') {
    input.type = 'text';
    btn.textContent = '🔒';
  } else {
    input.type = 'password';
    btn.textContent = '👁️';
  }
}

async function testApiKey() {
  const apiKey = document.getElementById('apiKey').value.trim();
  const statusEl = document.getElementById('apiKeyStatus');
  
  if (!apiKey || apiKey.includes('•')) {
    showStatus(statusEl, 'Please enter a valid API key first.', 'error');
    return;
  }

  const btn = document.getElementById('testApiKey');
  btn.disabled = true;
  btn.textContent = 'Testing...';

  try {
    const response = await chrome.runtime.sendMessage({
      type: 'TEST_API_KEY',
      apiKey: apiKey
    });

    if (response.success) {
      showStatus(statusEl, '✓ API key is valid and working!', 'success');
    } else {
      showStatus(statusEl, `✗ ${response.error || 'Invalid API key'}`, 'error');
    }
  } catch (error) {
    showStatus(statusEl, `✗ Error: ${error.message}`, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Test Connection';
  }
}

async function saveApiKey() {
  const apiKey = document.getElementById('apiKey').value.trim();
  const statusEl = document.getElementById('apiKeyStatus');

  if (!apiKey || apiKey.includes('•')) {
    showStatus(statusEl, 'Please enter a valid API key.', 'error');
    return;
  }

  if (!apiKey.startsWith('sk-')) {
    showStatus(statusEl, 'API key should start with "sk-"', 'error');
    return;
  }

  try {
    await chrome.runtime.sendMessage({
      type: 'SET_API_KEY',
      apiKey: apiKey
    });

    document.getElementById('apiKey').value = '••••••••••••••••••••••••••••••••';
    document.getElementById('apiKey').dataset.hasKey = 'true';
    showStatus(statusEl, '✓ API key saved successfully!', 'success');
  } catch (error) {
    showStatus(statusEl, `✗ Error saving API key: ${error.message}`, 'error');
  }
}

async function saveProfile() {
  const statusEl = document.getElementById('profileStatus');

  const profile = {
    name: document.getElementById('userName').value.trim(),
    title: document.getElementById('userTitle').value.trim(),
    company: document.getElementById('userCompany').value.trim(),
    industry: document.getElementById('userIndustry').value.trim(),
    bio: document.getElementById('userBio').value.trim()
  };

  try {
    await chrome.storage.sync.set({ user_profile: profile });
    showStatus(statusEl, '✓ Profile saved successfully!', 'success');
  } catch (error) {
    showStatus(statusEl, `✗ Error saving profile: ${error.message}`, 'error');
  }
}

async function savePreferences() {
  const statusEl = document.getElementById('preferencesStatus');

  const preferences = {
    defaultTone: document.getElementById('defaultTone').value,
    responseLength: document.getElementById('responseLength').value,
    includeEmojis: document.getElementById('includeEmojis').checked,
    includeHashtags: document.getElementById('includeHashtags').checked
  };

  try {
    await chrome.storage.sync.set({ preferences: preferences });
    showStatus(statusEl, '✓ Preferences saved successfully!', 'success');
  } catch (error) {
    showStatus(statusEl, `✗ Error saving preferences: ${error.message}`, 'error');
  }
}

function updateTemperatureDisplay() {
  const value = document.getElementById('temperature').value;
  document.getElementById('temperatureValue').textContent = (value / 100).toFixed(1);
}

async function saveAdvanced() {
  const statusEl = document.getElementById('advancedStatus');

  const advanced = {
    model: document.getElementById('aiModel').value,
    temperature: parseInt(document.getElementById('temperature').value) / 100
  };

  try {
    await chrome.storage.sync.set({ advanced_settings: advanced });
    showStatus(statusEl, '✓ Advanced settings saved successfully!', 'success');
  } catch (error) {
    showStatus(statusEl, `✗ Error saving settings: ${error.message}`, 'error');
  }
}

async function exportData() {
  try {
    const data = await chrome.storage.sync.get(null);
    
    // Remove sensitive data
    const exportData = { ...data };
    if (exportData.openai_api_key) {
      exportData.openai_api_key = '[REDACTED]';
    }

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `linkedin-engage-ai-settings-${Date.now()}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
  } catch (error) {
    alert('Failed to export settings: ' + error.message);
  }
}

async function clearData() {
  if (!confirm('Are you sure you want to clear all data? This will remove your API key and all settings.')) {
    return;
  }

  try {
    await chrome.storage.sync.clear();
    await chrome.storage.local.clear();
    
    alert('All data has been cleared. The page will now reload.');
    location.reload();
  } catch (error) {
    alert('Failed to clear data: ' + error.message);
  }
}

function showStatus(element, message, type) {
  element.textContent = message;
  element.className = `status-message ${type}`;
  element.style.display = 'block';

  // Auto-hide after 5 seconds
  setTimeout(() => {
    element.style.display = 'none';
  }, 5000);
}
