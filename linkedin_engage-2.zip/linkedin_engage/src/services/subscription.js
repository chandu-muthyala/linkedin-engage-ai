/**
 * Subscription Service Module
 * Handles token-based usage and subscription management
 * Uses ONLY the users collection (no separate subscriptions collection)
 */

import { firebaseConfig } from '../config/firebase.config.js';

const FIRESTORE_BASE_URL = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/linkedinengageai/documents`;

// Subscription constants - easily adjustable
export const SUBSCRIPTION_CONFIG = {
  FREE_TOKENS: 20,           // Tokens given to new users
  PREMIUM_PRICE: 5,          // USD per month
  PREMIUM_UNLIMITED: true,   // Premium users have unlimited usage
};

// Account types
export const ACCOUNT_TYPE = {
  BASIC: 'basic',
  PREMIUM: 'premium',
};

/**
 * Build URL with API key
 */
function buildUrl(path) {
  const separator = path.includes('?') ? '&' : '?';
  return `${path}${separator}key=${firebaseConfig.apiKey}`;
}

/**
 * Get user data from Firestore (includes subscription info)
 * @param {string} userId - User ID
 * @returns {Promise<Object|null>} User data or null
 */
async function getUserFromFirestore(userId) {
  const url = buildUrl(`${FIRESTORE_BASE_URL}/users/${userId}`);
  
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });
    
    if (response.status === 404) {
      return null;
    }
    
    if (!response.ok) {
      const errorData = await response.json();
      if (errorData.error?.status === 'NOT_FOUND' || errorData.error?.code === 404) {
        return null;
      }
      throw new Error(`Failed to get user: ${errorData.error?.message}`);
    }
    
    const result = await response.json();
    return parseUserDocument(result);
  } catch (error) {
    if (error.message.includes('NOT_FOUND')) return null;
    console.error('[Subscription] Error getting user:', error);
    throw error;
  }
}

/**
 * Update user subscription fields in Firestore
 * @param {string} userId - User ID
 * @param {Object} updates - Fields to update
 * @returns {Promise<Object>} Updated user data
 */
async function updateUserSubscription(userId, updates) {
  const updateMask = Object.keys(updates).map(f => `updateMask.fieldPaths=${f}`).join('&');
  const url = buildUrl(`${FIRESTORE_BASE_URL}/users/${userId}?${updateMask}`);
  
  const fields = {};
  for (const [key, value] of Object.entries(updates)) {
    if (typeof value === 'number') {
      fields[key] = { integerValue: String(value) };
    } else if (typeof value === 'string') {
      fields[key] = { stringValue: value };
    } else if (value instanceof Date) {
      fields[key] = { timestampValue: value.toISOString() };
    } else if (value === null) {
      fields[key] = { nullValue: null };
    }
  }
  
  try {
    const response = await fetch(url, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Failed to update user: ${errorData.error?.message}`);
    }
    
    console.log('[Subscription] Updated user:', userId, updates);
    return parseUserDocument(await response.json());
  } catch (error) {
    console.error('[Subscription] Error updating user:', error);
    throw error;
  }
}

/**
 * Parse Firestore user document
 * IMPORTANT: Returns actual values from Firebase - does NOT default tokensRemaining
 */
function parseUserDocument(doc) {
  if (!doc || !doc.fields) return null;
  
  const fields = doc.fields;
  
  // Parse tokensRemaining - return actual value, null if missing (do NOT default to 20)
  let tokensRemaining = null;
  if (fields.tokensRemaining?.integerValue !== undefined) {
    tokensRemaining = parseInt(fields.tokensRemaining.integerValue, 10);
  }
  
  return {
    uid: fields.uid?.stringValue || '',
    email: fields.email?.stringValue || '',
    displayName: fields.displayName?.stringValue || '',
    accountType: fields.accountType?.stringValue || ACCOUNT_TYPE.BASIC,
    tokensRemaining: tokensRemaining,
    tokensUsed: parseInt(fields.tokensUsed?.integerValue || '0', 10),
    subscriptionStatus: fields.subscriptionStatus?.stringValue || 'inactive',
    subscriptionStartDate: fields.subscriptionStartDate?.timestampValue || null,
    subscriptionRenewalDate: fields.subscriptionRenewalDate?.timestampValue || null,
    hasTokensField: fields.tokensRemaining !== undefined, // Track if field exists in Firebase
  };
}

/**
 * Get user subscription data from users collection
 * @param {string} userId - User ID
 * @returns {Promise<Object|null>} Subscription data or null
 */
export async function getUserSubscription(userId) {
  const user = await getUserFromFirestore(userId);
  if (!user) return null;
  
  return {
    accountType: user.accountType,
    tokensRemaining: user.tokensRemaining,
    tokensUsed: user.tokensUsed,
    subscriptionStatus: user.subscriptionStatus,
    subscriptionStartDate: user.subscriptionStartDate,
    subscriptionRenewalDate: user.subscriptionRenewalDate,
  };
}

/**
 * Initialize subscription fields for a new user (called during registration)
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Subscription data
 */
export async function initializeUserSubscription(userId) {
  const updates = {
    accountType: ACCOUNT_TYPE.BASIC,
    tokensRemaining: SUBSCRIPTION_CONFIG.FREE_TOKENS,
    tokensUsed: 0,
    subscriptionStatus: 'inactive',
  };
  
  await updateUserSubscription(userId, updates);
  return updates;
}

/**
 * Save/update user subscription (updates users collection)
 * IMPORTANT: Only updates fields that are explicitly provided
 * @param {string} userId - User ID
 * @param {Object} subscriptionData - Subscription data
 * @returns {Promise<Object>} Updated subscription
 */
export async function saveUserSubscription(userId, subscriptionData) {
  // Only include fields that are explicitly provided - don't default to 20 tokens!
  const updates = {};
  
  if (subscriptionData.accountType !== undefined) {
    updates.accountType = subscriptionData.accountType;
  }
  if (subscriptionData.tokensRemaining !== undefined && subscriptionData.tokensRemaining !== null) {
    updates.tokensRemaining = subscriptionData.tokensRemaining;
  }
  if (subscriptionData.tokensUsed !== undefined) {
    updates.tokensUsed = subscriptionData.tokensUsed;
  }
  if (subscriptionData.subscriptionStatus !== undefined) {
    updates.subscriptionStatus = subscriptionData.subscriptionStatus;
  }
  if (subscriptionData.subscriptionStartDate) {
    updates.subscriptionStartDate = subscriptionData.subscriptionStartDate;
  }
  if (subscriptionData.subscriptionRenewalDate) {
    updates.subscriptionRenewalDate = subscriptionData.subscriptionRenewalDate;
  }
  
  if (Object.keys(updates).length === 0) {
    console.warn('[Subscription] No fields to update for user:', userId);
    return subscriptionData;
  }
  
  await updateUserSubscription(userId, updates);
  return updates;
}

/**
 * Check if user can make a request (has tokens or is premium)
 * @param {string} userId - User ID
 * @returns {Promise<Object>} { canRequest: boolean, reason?: string, subscription: Object }
 */
export async function checkUserCanRequest(userId) {
  let subscription = await getUserSubscription(userId);
  
  // If no subscription exists, user needs to be created first
  if (!subscription) {
    console.error('[Subscription] No user found for ID:', userId);
    return {
      canRequest: false,
      reason: 'user_not_found',
      subscription: null
    };
  }
  
  // Premium users can always request
  if (subscription.accountType === ACCOUNT_TYPE.PREMIUM) {
    if (subscription.subscriptionStatus === 'active') {
      return { canRequest: true, subscription };
    }
    // If premium but expired, treat as basic
  }
  
  // Basic users need tokens - check actual value from Firebase
  if (subscription.tokensRemaining !== null && subscription.tokensRemaining > 0) {
    return { canRequest: true, subscription };
  }
  
  return {
    canRequest: false,
    reason: 'no_tokens',
    subscription
  };
}

/**
 * Consume one token for a request
 * Updates the users collection directly
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Updated subscription with tokensRemaining
 */
export async function consumeToken(userId) {
  const subscription = await getUserSubscription(userId);
  
  if (!subscription) {
    throw new Error('No subscription found for user');
  }
  
  // Premium users don't consume tokens
  if (subscription.accountType === ACCOUNT_TYPE.PREMIUM && subscription.subscriptionStatus === 'active') {
    // Just update usage count for analytics
    const newTokensUsed = (subscription.tokensUsed || 0) + 1;
    await updateUserSubscription(userId, { tokensUsed: newTokensUsed });
    return { ...subscription, tokensUsed: newTokensUsed, tokensRemaining: -1 }; // -1 indicates unlimited
  }
  
  // Basic users consume tokens - check if tokensRemaining is null or 0
  if (subscription.tokensRemaining === null || subscription.tokensRemaining === undefined) {
    throw new Error('Token count not found in Firebase for user');
  }
  
  if (subscription.tokensRemaining <= 0) {
    throw new Error('No tokens remaining');
  }
  
  const newTokenCount = subscription.tokensRemaining - 1;
  const newTokensUsed = (subscription.tokensUsed || 0) + 1;
  
  await updateUserSubscription(userId, {
    tokensRemaining: newTokenCount,
    tokensUsed: newTokensUsed,
  });
  
  console.log('[Subscription] Token consumed for user:', userId, 'Remaining:', newTokenCount, 'Used:', newTokensUsed);
  
  return { ...subscription, tokensRemaining: newTokenCount, tokensUsed: newTokensUsed };
}

/**
 * Upgrade user to premium
 * @param {string} userId - User ID
 * @param {Object} paymentDetails - Payment confirmation details
 * @returns {Promise<Object>} Updated subscription
 */
export async function upgradeToPremium(userId, paymentDetails = {}) {
  const now = new Date();
  const renewalDate = new Date(now);
  renewalDate.setMonth(renewalDate.getMonth() + 1);
  
  const updates = {
    accountType: ACCOUNT_TYPE.PREMIUM,
    subscriptionStatus: 'active',
    subscriptionStartDate: now.toISOString(),
    subscriptionRenewalDate: renewalDate.toISOString(),
  };
  
  await updateUserSubscription(userId, updates);
  return updates;
}

/**
 * Downgrade user to basic (when subscription expires)
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Updated subscription
 */
export async function downgradeToBasic(userId) {
  const updates = {
    accountType: ACCOUNT_TYPE.BASIC,
    subscriptionStatus: 'expired',
  };
  
  await updateUserSubscription(userId, updates);
  return updates;
}

/**
 * Get subscription summary for display
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Summary for UI
 */
export async function getSubscriptionSummary(userId) {
  let subscription = await getUserSubscription(userId);
  
  if (!subscription) {
    subscription = await initializeUserSubscription(userId);
  }
  
  const isPremium = subscription.accountType === ACCOUNT_TYPE.PREMIUM && 
                    subscription.subscriptionStatus === 'active';
  
  return {
    isPremium,
    accountType: subscription.accountType,
    tokensRemaining: subscription.tokensRemaining,
    tokensUsed: subscription.tokensUsed,
    subscriptionStatus: subscription.subscriptionStatus,
    renewalDate: subscription.subscriptionRenewalDate,
    canRequest: isPremium || subscription.tokensRemaining > 0,
  };
}
