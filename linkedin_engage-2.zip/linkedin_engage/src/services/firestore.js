/**
 * Firestore Service Module
 * Handles all database operations for storing user authentication data
 */

import { firebaseConfig } from '../config/firebase.config.js';

const FIRESTORE_BASE_URL = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/linkedinengageai/documents`;

/**
 * Get the authorization header - uses API key for Firestore access
 * @returns {Object} Headers object with authorization
 */
function getHeaders() {
    return {
        'Content-Type': 'application/json'
    };
}

/**
 * Build URL with API key
 * @param {string} path - API path
 * @returns {string} Full URL with API key
 */
function buildUrl(path) {
    const separator = path.includes('?') ? '&' : '?';
    return `${path}${separator}key=${firebaseConfig.apiKey}`;
}

// Subscription constants
const SUBSCRIPTION_CONFIG = {
    FREE_TOKENS: 20,
    ACCOUNT_TYPE_BASIC: 'basic',
    ACCOUNT_TYPE_PREMIUM: 'premium'
};

/**
 * Ensure user has a subscription document in Firestore
 * Creates one with default free tokens if it doesn't exist
 * @param {string} userId - User ID
 * @returns {Promise<Object>} - Subscription data
 */
async function ensureUserSubscription(userId) {
    const subscriptionUrl = buildUrl(`${FIRESTORE_BASE_URL}/subscriptions/${userId}`);
    
    try {
        // Check if subscription already exists
        const getResponse = await fetch(subscriptionUrl, {
            method: 'GET',
            headers: getHeaders()
        });
        
        if (getResponse.ok) {
            // Subscription exists - sync to users collection
            const existing = await getResponse.json();
            console.log('[Firestore] Subscription already exists for user:', userId);
            
            // Sync existing subscription data to users collection
            const subFields = existing.fields;
            if (subFields) {
                await syncSubscriptionToUserDoc(userId, {
                    tokensRemaining: parseInt(subFields.tokensRemaining?.integerValue || '0', 10),
                    accountType: subFields.accountType?.stringValue || SUBSCRIPTION_CONFIG.ACCOUNT_TYPE_BASIC
                });
            }
            
            return existing;
        }
        
        // Create new subscription
        const now = new Date().toISOString();
        const subscriptionDocument = {
            fields: {
                accountType: { stringValue: SUBSCRIPTION_CONFIG.ACCOUNT_TYPE_BASIC },
                tokensRemaining: { integerValue: String(SUBSCRIPTION_CONFIG.FREE_TOKENS) },
                tokensUsed: { integerValue: '0' },
                subscriptionStatus: { stringValue: 'inactive' },
                subscriptionStartDate: { nullValue: null },
                subscriptionRenewalDate: { nullValue: null },
                createdAt: { timestampValue: now },
                updatedAt: { timestampValue: now }
            }
        };
        
        const createResponse = await fetch(subscriptionUrl, {
            method: 'PATCH',
            headers: getHeaders(),
            body: JSON.stringify(subscriptionDocument)
        });
        
        if (!createResponse.ok) {
            const errorData = await createResponse.json();
            throw new Error(`Failed to create subscription: ${errorData.error?.message}`);
        }
        
        console.log('[Firestore] Created new subscription for user:', userId);
        
        // Sync new subscription to users collection
        await syncSubscriptionToUserDoc(userId, {
            tokensRemaining: SUBSCRIPTION_CONFIG.FREE_TOKENS,
            accountType: SUBSCRIPTION_CONFIG.ACCOUNT_TYPE_BASIC
        });
        
        return await createResponse.json();
        
    } catch (error) {
        console.error('[Firestore] Error ensuring subscription:', error);
        // Don't throw - subscription creation should not block sign-in
        return null;
    }
}

/**
 * Sync subscription data (tokensRemaining, accountType) to users collection
 */
async function syncSubscriptionToUserDoc(userId, data) {
    const userUrl = buildUrl(`${FIRESTORE_BASE_URL}/users/${userId}?updateMask.fieldPaths=tokensRemaining&updateMask.fieldPaths=accountType`);
    
    try {
        const response = await fetch(userUrl, {
            method: 'PATCH',
            headers: getHeaders(),
            body: JSON.stringify({
                fields: {
                    tokensRemaining: { integerValue: String(data.tokensRemaining) },
                    accountType: { stringValue: data.accountType }
                }
            })
        });
        
        if (response.ok) {
            console.log('[Firestore] Synced subscription to user document:', userId);
        }
    } catch (error) {
        console.error('[Firestore] Failed to sync subscription to user:', error);
    }
}

/**
 * Save user authentication data to Firestore
 * @param {Object} userData - User data from Google Sign-In
 * @param {string} userData.id - Google user ID
 * @param {string} userData.email - User email
 * @param {string} userData.name - User display name
 * @param {string} userData.picture - User profile picture URL
 * @returns {Promise<Object|null>} - Saved user document or null if already exists
 */

export async function saveUserToFirestore(userData) {
    const { id, email, name, picture } = userData;
    const now = new Date().toISOString();
    const extensionVersion = chrome.runtime.getManifest().version;

    try {
        // Check if user already exists in database
        const existingUser = await getUserFromFirestore(id);
        
        if (existingUser) {
            // User exists - update signInTime and lastActiveTime only
            // extensionVersion is NOT updated - it tracks when user first joined
            console.log('[Firestore] User exists, updating sign-in info:', id);
            

            // Build update data - always update signInTime and lastActiveTime
            const updateData = {
                signInTime: now,
                lastActiveTime: now
            };
            
            // Add tokensRemaining if missing from user document
            if (existingUser.tokensRemaining === undefined || existingUser.tokensRemaining === null) {
                updateData.tokensRemaining = SUBSCRIPTION_CONFIG.FREE_TOKENS;
                console.log('[Firestore] Adding missing tokensRemaining to user:', id);
            }
            
            // Add accountType if missing from user document
            if (!existingUser.accountType) {
                updateData.accountType = SUBSCRIPTION_CONFIG.ACCOUNT_TYPE_BASIC;
                console.log('[Firestore] Adding missing accountType to user:', id);
            }
            
            await updateUserInFirestore(id, updateData);
            
            // Ensure subscription exists for this user
            await ensureUserSubscription(id);
            
            return existingUser;
        }
        
        // Create new user document with accountType
        const userDocument = {
            fields: {
                uid: { stringValue: id },
                email: { stringValue: email || '' },
                displayName: { stringValue: name || '' },
                photoURL: { stringValue: picture || '' },
                signInTime: { timestampValue: now },
                lastActiveTime: { timestampValue: now },
                createdAt: { timestampValue: now },
                platform: { stringValue: 'chrome_extension' },
                extensionVersion: { stringValue: extensionVersion },
                accountType: { stringValue: 'basic' },
                tokensRemaining: { integerValue: '20' }
            }
        };
        
        const url = buildUrl(`${FIRESTORE_BASE_URL}/users?documentId=${id}`);
        
        const response = await fetch(url, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify(userDocument)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Firestore save failed: ${errorData.error?.message || response.statusText}`);
        }

        const result = await response.json();
        console.log('[Firestore] New user saved successfully:', id);
        

        // Also create subscription document for new user
        await ensureUserSubscription(id);
        
        return result;
    } catch (error) {
        console.error('[Firestore] Error saving user:', error);
        throw error;
    }
}

/**
 * Get user data from Firestore
 * @param {string} userId - Google user ID
 * @returns {Promise<Object|null>} - User document or null if not found
 */

export async function getUserFromFirestore(userId) {
    const url = buildUrl(`${FIRESTORE_BASE_URL}/users/${userId}`);
    
    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: getHeaders()
        });

        if (response.status === 404) {
            console.log('[Firestore] User not found:', userId);
            return null;
        }

        if (!response.ok) {
            const errorData = await response.json();
            // If it's a NOT_FOUND error, return null instead of throwing
            if (errorData.error?.status === 'NOT_FOUND' || errorData.error?.code === 404) {
                console.log('[Firestore] User not found:', userId);
                return null;
            }
            throw new Error(`Firestore get failed: ${errorData.error?.message || response.statusText}`);
        }

        const result = await response.json();
        return parseFirestoreDocument(result);
    } catch (error) {
        if (error.message.includes('NOT_FOUND') || error.message.includes('not found')) {
            return null;
        }
        console.error('[Firestore] Error getting user:', error);
        throw error;
    }
}

/**
 * Update user data in Firestore
 * @param {string} userId - Google user ID
 * @param {Object} updateData - Fields to update
 * @returns {Promise<Object>} - Updated user document
 */

export async function updateUserInFirestore(userId, updateData) {
    const baseUrl = `${FIRESTORE_BASE_URL}/users/${userId}`;
    
    const fields = {};
    const updateMask = [];
    
    for (const [key, value] of Object.entries(updateData)) {
        updateMask.push(key);
        if (key.includes('Time') || key === 'createdAt') {
            fields[key] = { timestampValue: value };
        } else if (key === 'tokensRemaining' || key === 'tokensUsed') {
            fields[key] = { integerValue: String(value) };
        } else {
            fields[key] = { stringValue: String(value) };
        }
    }

    const patchUrl = buildUrl(`${baseUrl}?${updateMask.map(field => `updateMask.fieldPaths=${field}`).join('&')}`);
    
    try {
        const response = await fetch(patchUrl, {
            method: 'PATCH',
            headers: getHeaders(),
            body: JSON.stringify({ fields })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Firestore update failed: ${errorData.error?.message || response.statusText}`);
        }

        const result = await response.json();
        console.log('[Firestore] User updated successfully:', userId);
        return parseFirestoreDocument(result);
    } catch (error) {
        console.error('[Firestore] Error updating user:', error);
        throw error;
    }
}

/**
 * Update user's last active time
 * @param {string} userId - Google user ID
 * @returns {Promise<Object>} - Updated user document
 */

export async function updateLastActiveTime(userId) {
    return await updateUserInFirestore(userId, {
        lastActiveTime: new Date().toISOString()
    });
}

/**
 * Delete user data from Firestore
 * @param {string} userId - Google user ID
 * @returns {Promise<boolean>} - True if deleted successfully
 */

export async function deleteUserFromFirestore(userId) {
    const url = buildUrl(`${FIRESTORE_BASE_URL}/users/${userId}`);
    
    try {
        const response = await fetch(url, {
            method: 'DELETE',
            headers: getHeaders()
        });

        if (!response.ok && response.status !== 404) {
            const errorData = await response.json();
            throw new Error(`Firestore delete failed: ${errorData.error?.message || response.statusText}`);
        }

        console.log('[Firestore] User deleted successfully:', userId);
        return true;
    } catch (error) {
        console.error('[Firestore] Error deleting user:', error);
        throw error;
    }
}

/**
 * Log user activity/engagement to Firestore
 * @param {string} userId - Google user ID
 * @param {Object} activityData - Activity details
 * @param {string} activityData.type - Type of activity (e.g., 'engagement_generated')
 * @param {string} activityData.tone - Engagement tone used
 * @returns {Promise<Object>} - Saved activity document
 */

export async function logUserActivity(userId, activityData) {
    const activityId = `${userId}_${Date.now()}`;
    const url = buildUrl(`${FIRESTORE_BASE_URL}/activities?documentId=${activityId}`);
    
    const activityDocument = {
        fields: {
            userId: { stringValue: userId },
            type: { stringValue: activityData.type || 'engagement' },
            tone: { stringValue: activityData.tone || '' },
            timestamp: { timestampValue: new Date().toISOString() },
            metadata: { stringValue: JSON.stringify(activityData.metadata || {}) }
        }
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify(activityDocument)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Firestore activity log failed: ${errorData.error?.message || response.statusText}`);
        }

        return await response.json();
    } catch (error) {
        console.error('[Firestore] Error logging activity:', error);
        // Don't throw - activity logging shouldn't break the main flow
        return null;
    }
}

/**
 * Parse Firestore document to plain JavaScript object
 * @param {Object} doc - Firestore document
 * @returns {Object} - Parsed object
 */
function parseFirestoreDocument(doc) {
    if (!doc || !doc.fields) {
        return null;
    }

    const result = {};
    
    for (const [key, value] of Object.entries(doc.fields)) {
        if (value.stringValue !== undefined) {
            result[key] = value.stringValue;
        } else if (value.integerValue !== undefined) {
            result[key] = parseInt(value.integerValue, 10);
        } else if (value.doubleValue !== undefined) {
            result[key] = value.doubleValue;
        } else if (value.booleanValue !== undefined) {
            result[key] = value.booleanValue;
        } else if (value.timestampValue !== undefined) {
            result[key] = value.timestampValue;
        } else if (value.arrayValue !== undefined) {
            result[key] = value.arrayValue.values?.map(v => Object.values(v)[0]) || [];
        } else if (value.mapValue !== undefined) {
            result[key] = parseFirestoreDocument(value.mapValue);
        }
    }

    return result;
}

/**
 * Get user statistics from Firestore
 * @param {string} userId - Google user ID
 * @returns {Promise<Object>} - User statistics
 */

export async function getUserStats(userId) {
    // Query activities for this user
    const url = buildUrl(`${FIRESTORE_BASE_URL}:runQuery`);
    
    const query = {
        structuredQuery: {
            from: [{ collectionId: 'activities' }],
            where: {
                fieldFilter: {
                    field: { fieldPath: 'userId' },
                    op: 'EQUAL',
                    value: { stringValue: userId }
                }
            },
            orderBy: [{ field: { fieldPath: 'timestamp' }, direction: 'DESCENDING' }],
            limit: 100
        }
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify(query)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Firestore query failed: ${errorData.error?.message || response.statusText}`);
        }

        const results = await response.json();
        const activities = results
            .filter(r => r.document)
            .map(r => parseFirestoreDocument(r.document));

        // Calculate stats
        const stats = {
            totalEngagements: activities.length,
            toneBreakdown: {},
            lastActivity: activities[0]?.timestamp || null
        };

        activities.forEach(activity => {
            if (activity.tone) {
                stats.toneBreakdown[activity.tone] = (stats.toneBreakdown[activity.tone] || 0) + 1;
            }
        });

        return stats;
    } catch (error) {
        console.error('[Firestore] Error getting user stats:', error);
        return { totalEngagements: 0, toneBreakdown: {}, lastActivity: null };
    }
}
