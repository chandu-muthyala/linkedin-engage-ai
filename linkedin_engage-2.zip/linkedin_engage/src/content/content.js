/**
 * LinkedIn Engage AI - Content Script
 * Injects engagement UI into LinkedIn posts and comments
 */

const AUTH_STORAGE_KEY = 'linkedin_engage_auth';

const ENGAGEMENT_OPTIONS = [
  { id: 'lighthearted', label: 'Lighthearted', icon: '😊', description: 'Friendly and warm' },
  { id: 'reply_comment', label: 'Reply comment', icon: '💬', description: 'Direct response' },
  { id: 'dm', label: 'DM', icon: '✉️', description: 'Private message' },
  { id: 'support', label: 'Support', icon: '👏', description: 'Encouragement' },
  { id: 'add_opinion', label: 'Add opinion', icon: '💡', description: 'Share perspective' },
  { id: 'ask_question', label: 'Ask question', icon: '❓', description: 'Start conversation' },
  { id: 'answer_question', label: 'Answer question', icon: '✅', description: 'Provide answer' },
  { id: 'share_resources', label: 'Share resources', icon: '📚', description: 'Recommend tools' },
  { id: 'make_intro', label: 'Make an intro', icon: '🤝', description: 'Connect people' },
  { id: 'custom', label: '+', icon: '➕', description: 'Custom tone' }
];

class LinkedInEngageAI {
  constructor() {
    this.processedPosts = new Set();
    this.currentPanel = null;
    this.currentInputField = null;
    this.isInitialized = false;
    this.isAuthenticated = false;
    this.debounceTimer = null;
    this.init();
  }

  async init() {
    // Check authentication status first
    await this.checkAuthStatus();
    
    if (!this.isAuthenticated) {
      console.log('LinkedIn Engage AI: User not authenticated. Please sign in via the extension popup.');
      // Listen for auth state changes
      this.setupAuthListener();
      return;
    }
    
    this.startExtension();
  }
  

  async checkAuthStatus() {
    try {
      const result = await chrome.storage.local.get([AUTH_STORAGE_KEY]);
      const authData = result[AUTH_STORAGE_KEY];
      
      // Just check if user data exists - don't verify token validity
      // Token will be refreshed automatically when needed
      if (authData && authData.user) {
        this.isAuthenticated = true;
      } else {
        this.isAuthenticated = false;
      }
    } catch (error) {
      console.error('Auth check error:', error);
      this.isAuthenticated = false;
    }
  }
  
  setupAuthListener() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'AUTH_STATE_CHANGED') {
        if (message.isAuthenticated && !this.isInitialized) {
          this.isAuthenticated = true;
          this.startExtension();
        } else if (!message.isAuthenticated) {
          this.isAuthenticated = false;
          this.removeAllButtons();
        }
      }
      return true;
    });
  }
  
  removeAllButtons() {
    // Remove all engage buttons from the page
    document.querySelectorAll('.linkedin-engage-ai-input-trigger').forEach(btn => btn.remove());
    this.closeEngagePanel();
  }
  
  startExtension() {
    this.observeDOM();
    this.injectEngageButtons();
    this.setupMessageListener();
    this.setupFocusListener();
    this.isInitialized = true;
    console.log('LinkedIn Engage AI initialized');
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'ENGAGEMENT_RESPONSE') {
        this.displayResults(message.data);
      }
      if (message.type === 'AUTH_STATE_CHANGED') {
        if (message.isAuthenticated && !this.isInitialized) {
          this.isAuthenticated = true;
          this.startExtension();
        } else if (!message.isAuthenticated) {
          this.isAuthenticated = false;
          this.removeAllButtons();
        }
      }
      return true;
    });
  }

  setupFocusListener() {
    // Immediately inject button when user focuses on a comment input
    document.addEventListener('focusin', async (e) => {
      // Check auth before injecting
      if (!this.isAuthenticated) {
        await this.checkAuthStatus();
        if (!this.isAuthenticated) return;
      }
      
      const editor = e.target.closest('.ql-editor, [contenteditable="true"]');
      if (editor && editor.closest('.comments-comment-box, .comments-reply-box, .comments-comment-texteditor')) {
        this.attachButtonToEditor(editor);
      }
    }, true);
  }

  observeDOM() {
    const observer = new MutationObserver((mutations) => {
      let shouldInject = false;
      mutations.forEach((mutation) => {
        if (mutation.addedNodes.length > 0) {
          shouldInject = true;
        }
      });
      if (shouldInject) {
        // Reduced debounce timer for faster response
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(() => this.injectEngageButtons(), 100);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  injectEngageButtons() {
    // Find all comment/reply input fields on LinkedIn
    this.findAndAttachToInputFields();
    
    // Also find posts for context extraction
    const posts = document.querySelectorAll('[data-urn*="urn:li:activity"], .feed-shared-update-v2');
    posts.forEach((post) => {
      const postId = post.getAttribute('data-urn') || post.getAttribute('data-id') || this.generatePostId(post);
      this.processedPosts.add(postId);
    });
  }

  findAndAttachToInputFields() {
    // Find all contenteditable comment/reply input fields on LinkedIn
    // Target the actual editor elements, not containers
    const editorSelectors = [
      '.comments-comment-box .ql-editor',
      '.comments-comment-texteditor .ql-editor', 
      '.comments-reply-box .ql-editor',
      '.comments-comment-box [contenteditable="true"]',
      '.comments-reply-box [contenteditable="true"]',
      '.msg-form [contenteditable="true"]',
      '.comments-comment-box-comment__text-editor .ql-editor'
    ];

    editorSelectors.forEach(selector => {
      const editors = document.querySelectorAll(selector);
      editors.forEach(editor => {
        this.attachButtonToEditor(editor);
      });
    });
  }

  attachButtonToEditor(editor) {
    // Find the closest form/container for this editor
    const inputContainer = editor.closest('.comments-comment-box, .comments-comment-texteditor, .comments-reply-box, .msg-form, .comments-comment-box-comment__text-editor');
    
    if (!inputContainer) return;
    
    // Check if THIS specific editor already has a button nearby
    // Use a data attribute on the editor itself
    if (editor.dataset.engageAiAttached === 'true') return;
    
    // Check if button already exists in immediate container
    const existingBtn = inputContainer.querySelector('.linkedin-engage-ai-input-trigger');
    if (existingBtn) return;
    
    // Mark editor as processed
    editor.dataset.engageAiAttached = 'true';

    // Find the post context for this input
    const post = this.findParentPost(inputContainer);
    const postId = post ? (post.getAttribute('data-urn') || post.getAttribute('data-id') || this.generatePostId(post)) : 'unknown';
    
    // Also try to find the specific comment being replied to (for nested replies)
    const parentComment = this.findParentComment(inputContainer);

    // Check if this is a reply box (nested comment)
    const isReplyBox = inputContainer.classList.contains('comments-reply-box') || 
                       inputContainer.closest('.comments-reply-box') !== null ||
                       parentComment !== null;

    // Create the engage button using a div instead of button to avoid form interference
    const engageBtn = document.createElement('div');
    engageBtn.className = 'linkedin-engage-ai-input-trigger' + (isReplyBox ? ' engage-reply-btn' : '');
    engageBtn.setAttribute('role', 'button');
    engageBtn.setAttribute('tabindex', '0');
    engageBtn.innerHTML = `<span class="engage-icon">✨</span>`;
    engageBtn.setAttribute('data-post-id', postId);
    engageBtn.setAttribute('title', 'Generate AI response');

    // Store reference to the editor
    const editorRef = editor;
    const self = this;
    
    // Use onclick property directly for maximum compatibility
    engageBtn.onclick = function(e) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      console.log('Engage AI button clicked - onclick');
      self.currentInputField = editorRef;
      self.showEngagePanel(post || inputContainer, postId, engageBtn, parentComment);
      return false;
    };
    
    // Also add event listeners as backup
    engageBtn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      console.log('Engage AI button clicked - addEventListener');
      self.currentInputField = editorRef;
      self.showEngagePanel(post || inputContainer, postId, engageBtn, parentComment);
      return false;
    }, true);
    
    engageBtn.addEventListener('mousedown', function(e) {
      e.stopPropagation();
      e.stopImmediatePropagation();
    }, true);
    
    engageBtn.addEventListener('mouseup', function(e) {
      e.stopPropagation();
      e.stopImmediatePropagation();
    }, true);
    
    engageBtn.addEventListener('pointerdown', function(e) {
      e.stopPropagation();
      e.stopImmediatePropagation();
    }, true);

    // Find the best place to insert the button
    this.insertButtonNearInput(inputContainer, engageBtn, isReplyBox);
  }

  insertButtonNearInput(inputContainer, engageBtn, isReplyBox = false) {
    if (isReplyBox) {
      // For reply box: insert next to emoji/image icons (left side, after image icon)
      // First try to find the image attachment button
      const imageBtn = inputContainer.querySelector(
        'button[aria-label*="image"], ' +
        'button[aria-label*="photo"], ' +
        'button[aria-label*="media"], ' +
        'button[aria-label*="Image"], ' +
        'button[aria-label*="Photo"], ' +
        '.comments-comment-box__media-attachment-btn, ' +
        '.comments-comment-box-comment__media-attachment-btn, ' +
        '[class*="media-attachment"], ' +
        '[data-test-icon="image-medium"]'
      );
      
      if (imageBtn) {
        // Insert right after the image button
        imageBtn.parentElement.insertBefore(engageBtn, imageBtn.nextSibling);
        console.log('Inserted after image button');
      } else {
        // Try to find emoji button and insert after it
        const emojiBtn = inputContainer.querySelector(
          'button[aria-label*="emoji"], ' +
          'button[aria-label*="Emoji"], ' +
          '.comments-comment-box__emoji-btn, ' +
          '[class*="emoji"]'
        );
        
        if (emojiBtn) {
          emojiBtn.parentElement.insertBefore(engageBtn, emojiBtn.nextSibling);
          console.log('Inserted after emoji button');
        } else {
          // Try to find the form controls row
          const formControls = inputContainer.querySelector(
            '.comments-comment-box-comment__controls, ' +
            '.comments-comment-box__controls, ' +
            'form > div:last-child, ' +
            '[class*="controls"]'
          );
          
          if (formControls) {
            // Insert at the beginning (left side)
            if (formControls.firstChild) {
              formControls.insertBefore(engageBtn, formControls.firstChild);
            } else {
              formControls.appendChild(engageBtn);
            }
            console.log('Inserted in form controls');
          } else {
            // Last resort: append to container
            inputContainer.appendChild(engageBtn);
            console.log('Appended to container');
          }
        }
      }
    } else {
      // For main comment box: absolute position inside editor (right side centered)
      const editor = inputContainer.querySelector('.ql-editor, [contenteditable="true"]');
      
      if (editor) {
        const editorParent = editor.parentElement;
        
        if (editorParent && getComputedStyle(editorParent).position === 'static') {
          editorParent.style.position = 'relative';
        }
        
        editorParent.appendChild(engageBtn);
      } else {
        inputContainer.style.position = 'relative';
        inputContainer.appendChild(engageBtn);
      }
    }
    
    console.log('Engage AI button inserted', isReplyBox ? '(reply)' : '(comment)');
  }
  
  findParentComment(element) {
    // Find the comment that this reply box is replying to
    const commentItem = element.closest('.comments-comment-item, .comments-reply-item, .feed-shared-comment-item');
    if (commentItem) {
      const commentText = commentItem.querySelector('.comments-comment-item__main-content, .feed-shared-comment__text');
      if (commentText) {
        return commentText.innerText.trim();
      }
    }
    return null;
  }

  findParentPost(element) {
    return element.closest('[data-urn*="urn:li:activity"], .feed-shared-update-v2, .occludable-update');
  }

  generatePostId(post) {
    return 'post_' + Math.random().toString(36).substr(2, 9);
  }

  extractPostContent(post) {
    // Extract main post text
    const textElements = post.querySelectorAll('.feed-shared-text, .break-words, .feed-shared-update-v2__description, .update-components-text');
    let postText = '';
    
    textElements.forEach((el) => {
      postText += el.innerText + ' ';
    });

    // Extract author info
    const authorElement = post.querySelector('.feed-shared-actor__name, .update-components-actor__name');
    const authorName = authorElement ? authorElement.innerText.trim() : 'Unknown';

    // Extract author headline
    const headlineElement = post.querySelector('.feed-shared-actor__description, .update-components-actor__description');
    const authorHeadline = headlineElement ? headlineElement.innerText.trim() : '';

    return {
      text: postText.trim(),
      author: authorName,
      headline: authorHeadline,
      timestamp: new Date().toISOString()
    };
  }

  showEngagePanel(post, postId, triggerBtn = null, parentComment = null) {
    console.log('showEngagePanel called', { post, postId, triggerBtn, parentComment });
    
    // Store the current input field reference BEFORE closing old panel
    const savedInputField = this.currentInputField;
    
    // Remove any existing panel
    this.closeEngagePanel();
    
    // Restore the input field reference
    this.currentInputField = savedInputField;

    const postContent = this.extractPostContent(post);
    
    // Add parent comment context if this is a nested reply
    if (parentComment) {
      postContent.replyingTo = parentComment;
    }
    
    // Create the panel
    const panel = document.createElement('div');
    panel.className = 'linkedin-engage-ai-panel';
    panel.setAttribute('data-post-id', postId);
    
    // Store the input field reference on the panel itself
    panel.targetInputField = this.currentInputField;

    panel.innerHTML = `
      <div class="engage-panel-header">
        <span class="engage-panel-title">✨ LinkedIn Engage AI</span>
        <button class="engage-panel-close">&times;</button>
      </div>
      <div class="engage-panel-content">
        <div class="engage-options-grid">
          ${ENGAGEMENT_OPTIONS.map(option => `
            <button class="engage-option-btn" data-tone="${option.id}" title="${option.description}">
              <span class="option-icon">${option.icon}</span>
              <span class="option-label">${option.label}</span>
            </button>
          `).join('')}
        </div>
        <div class="engage-custom-input" style="display: none;">
          <input type="text" placeholder="Enter custom tone (e.g., professional, casual, witty...)" class="custom-tone-input">
          <button class="custom-tone-submit">Generate</button>
        </div>
        <div class="engage-results" style="display: none;">
          <div class="results-header">
            <span>Generated Responses</span>
            <button class="back-to-options">← Back</button>
          </div>
          <div class="results-loading" style="display: none;">
            <div class="loading-spinner"></div>
            <span>Generating responses...</span>
          </div>
          <div class="results-list"></div>
        </div>
      </div>
    `;

    // Store post content in panel data
    panel.postContent = postContent;

    // Add event listeners
    panel.querySelector('.engage-panel-close').addEventListener('click', () => this.closeEngagePanel());
    
    panel.querySelectorAll('.engage-option-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const tone = btn.getAttribute('data-tone');
        if (tone === 'custom') {
          this.showCustomInput(panel);
        } else {
          this.generateEngagement(panel, postContent, tone);
        }
      });
    });

    panel.querySelector('.custom-tone-submit')?.addEventListener('click', () => {
      const customTone = panel.querySelector('.custom-tone-input').value.trim();
      if (customTone) {
        this.generateEngagement(panel, postContent, 'custom', customTone);
      }
    });

    panel.querySelector('.back-to-options')?.addEventListener('click', () => {
      this.showOptionsGrid(panel);
    });

    // Position panel as dropdown attached to the input field
    const inputField = this.currentInputField;
    const inputContainer = inputField ? inputField.closest('.comments-comment-box, .comments-comment-texteditor, .comments-reply-box, .msg-form, .comments-comment-box-comment__text-editor') : null;
    
    const targetElement = inputContainer || triggerBtn;
    
    if (targetElement) {
      // Make the target container relative so we can position absolutely inside it
      const originalPosition = targetElement.style.position;
      if (!targetElement.style.position || targetElement.style.position === 'static') {
        targetElement.style.position = 'relative';
      }
      
      // Use absolute positioning to attach to the input container
      panel.style.position = 'absolute';
      panel.style.top = '100%';
      panel.style.left = '0';
      panel.style.marginTop = '5px';
      
      // Make panel width match input container width (min 320px, max 400px)
      const rect = targetElement.getBoundingClientRect();
      const panelWidth = Math.max(rect.width, 320);
      panel.style.width = `${Math.min(panelWidth, 400)}px`;
      
      // Append to the input container so it stays attached
      targetElement.appendChild(panel);
      
      // Adjust if panel goes off screen
      setTimeout(() => {
        const panelRect = panel.getBoundingClientRect();
        // If goes off right edge, align to right edge
        if (panelRect.right > window.innerWidth - 10) {
          panel.style.left = 'auto';
          panel.style.right = '0';
        }
        // If goes off bottom, show above the input instead
        if (panelRect.bottom > window.innerHeight - 10) {
          panel.style.top = 'auto';
          panel.style.bottom = '100%';
          panel.style.marginTop = '0';
          panel.style.marginBottom = '5px';
        }
      }, 0);
    } else {
      // Fallback: append to body with fixed positioning
      document.body.appendChild(panel);
    }
    this.currentPanel = panel;

    // Close panel when clicking outside
    document.addEventListener('click', this.handleOutsideClick.bind(this));
  }

  handleOutsideClick(e) {
    if (this.currentPanel && !this.currentPanel.contains(e.target) && 
        !e.target.closest('.linkedin-engage-ai-trigger') && 
        !e.target.closest('.linkedin-engage-ai-input-trigger')) {
      this.closeEngagePanel();
    }
  }

  showCustomInput(panel) {
    panel.querySelector('.engage-options-grid').style.display = 'none';
    panel.querySelector('.engage-custom-input').style.display = 'flex';
    panel.querySelector('.engage-results').style.display = 'none';
  }

  showOptionsGrid(panel) {
    panel.querySelector('.engage-options-grid').style.display = 'grid';
    panel.querySelector('.engage-custom-input').style.display = 'none';
    panel.querySelector('.engage-results').style.display = 'none';
  }

  showResults(panel) {
    panel.querySelector('.engage-options-grid').style.display = 'none';
    panel.querySelector('.engage-custom-input').style.display = 'none';
    panel.querySelector('.engage-results').style.display = 'block';
  }

  async generateEngagement(panel, postContent, tone, customTone = null) {
    this.showResults(panel);
    
    const resultsLoading = panel.querySelector('.results-loading');
    const resultsList = panel.querySelector('.results-list');
    
    resultsLoading.style.display = 'flex';
    resultsList.innerHTML = '';

    console.log('Generating engagement:', { postContent, tone, customTone });

    try {
      // Check if we can connect to the background script
      if (!chrome.runtime?.id) {
        throw new Error('Extension context invalidated. Please refresh the page.');
      }

      // Send message to background script
      const response = await chrome.runtime.sendMessage({
        type: 'GENERATE_ENGAGEMENT',
        payload: {
          post_text: postContent.text || 'No post content found',
          post_author: postContent.author || 'Unknown',
          post_headline: postContent.headline || '',
          selected_tone: tone,
          custom_tone: customTone,
          replying_to: postContent.replyingTo || null
        }
      });

      console.log('Response from background:', response);

      resultsLoading.style.display = 'none';

      if (response.error) {

        // Handle no tokens error specially with upgrade prompt
        if (response.error === 'no_tokens') {
          resultsList.innerHTML = `
            <div class="result-error no-tokens-error">
              <span class="error-icon">🔒</span>
              <strong>Out of Free Tokens</strong>
              <p>${response.message || 'You have used all your free tokens.'}</p>
              <p>Upgrade to Premium for unlimited engagements at just $5/month!</p>
              <button class="upgrade-btn">⭐ Upgrade to Premium</button>
            </div>
          `;
          resultsList.querySelector('.upgrade-btn')?.addEventListener('click', () => {
            // Open extension popup or payment page
            chrome.runtime.sendMessage({ type: 'OPEN_UPGRADE_PAGE' });
          });
          return;
        }
        
        resultsList.innerHTML = `
          <div class="result-error">
            <span>⚠️ ${response.error}</span>
            <button class="retry-btn">Retry</button>
          </div>
        `;
        resultsList.querySelector('.retry-btn')?.addEventListener('click', () => {
          this.generateEngagement(panel, postContent, tone, customTone);
        });
        return;
      }

      this.displayResponsesInPanel(panel, response.data);
    } catch (error) {
      console.error('Generate engagement error:', error);
      resultsLoading.style.display = 'none';
      
      let errorMessage = 'Failed to generate response. Please try again.';
      if (error.message.includes('Extension context invalidated') || error.message.includes('Receiving end does not exist')) {
        errorMessage = 'Extension disconnected. Please refresh the page and try again.';
      }
      
      resultsList.innerHTML = `
        <div class="result-error">
          <span>⚠️ ${errorMessage}</span>
          <button class="retry-btn">Retry</button>
        </div>
      `;
      resultsList.querySelector('.retry-btn')?.addEventListener('click', () => {
        this.generateEngagement(panel, postContent, tone, customTone);
      });
    }
  }

  displayResponsesInPanel(panel, data) {
    const resultsList = panel.querySelector('.results-list');
    
    const allResponses = [
      { label: 'Primary', text: data.primary },
      ...data.alternatives.map((alt, i) => ({ label: `Alternative ${i + 1}`, text: alt }))
    ];

    resultsList.innerHTML = allResponses.map((response, index) => `
      <div class="result-item" data-index="${index}">
        <div class="result-label">${response.label}</div>
        <div class="result-text">${response.text}</div>
        <div class="result-actions">
          <button class="copy-btn" data-text="${this.escapeHtml(response.text)}">📋 Copy</button>
          <button class="insert-btn" data-text="${this.escapeHtml(response.text)}">📝 Insert</button>
        </div>
      </div>
    `).join('');

    // Add event listeners for copy and insert buttons
    resultsList.querySelectorAll('.copy-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const text = btn.getAttribute('data-text');
        this.copyToClipboard(text);
        btn.textContent = '✓ Copied!';
        setTimeout(() => { btn.textContent = '📋 Copy'; }, 2000);
      });
    });

    resultsList.querySelectorAll('.insert-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const text = btn.getAttribute('data-text');
        this.insertIntoCommentBox(text);
        btn.textContent = '✓ Inserted!';
        setTimeout(() => { btn.textContent = '📝 Insert'; }, 2000);
        
        // Update inserted stats
        chrome.runtime.sendMessage({ type: 'UPDATE_STATS', statType: 'inserted' })
          .catch(err => console.log('Stats update:', err));
      });
    });
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML.replace(/"/g, '&quot;');
  }

  copyToClipboard(text) {
    navigator.clipboard.writeText(text).catch((err) => {
      console.error('Failed to copy text:', err);
    });
  }

  insertIntoCommentBox(text) {
    // Get the target input field - prefer panel's stored reference
    const targetField = this.currentPanel?.targetInputField || this.currentInputField;
    
    if (targetField) {
      // Store reference before any async operations
      const inputField = targetField;
      
      // Scroll the input field into view
      inputField.scrollIntoView({ behavior: 'smooth', block: 'center' });
      
      // Small delay to ensure field is visible and focused
      setTimeout(() => {
        inputField.focus();
        
        // Handle different types of input fields
        if (inputField.tagName === 'TEXTAREA') {
          inputField.value = text;
          inputField.dispatchEvent(new Event('input', { bubbles: true }));
          inputField.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
          // For contenteditable elements (LinkedIn uses these)
          // Clear existing content first
          inputField.innerHTML = '';
          
          // Create a proper paragraph element
          const p = document.createElement('p');
          p.textContent = text;
          inputField.appendChild(p);
          
          // Move cursor to end
          const range = document.createRange();
          const sel = window.getSelection();
          range.selectNodeContents(inputField);
          range.collapse(false);
          sel.removeAllRanges();
          sel.addRange(range);
          
          // Trigger multiple events to ensure LinkedIn detects the change
          inputField.dispatchEvent(new Event('input', { bubbles: true }));
          inputField.dispatchEvent(new Event('change', { bubbles: true }));
          inputField.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
        }
        
        this.closeEngagePanel();
      }, 100);
      
      return;
    }

    // Fallback: Find the closest comment box
    const postId = this.currentPanel?.getAttribute('data-post-id');
    const post = document.querySelector(`[data-urn="${postId}"], [data-id="${postId}"]`) || 
                 this.currentPanel?.closest('.feed-shared-update-v2');
    
    if (post) {
      // Try to find and click the comment button first
      const commentBtn = post.querySelector('.comment-button, [data-control-name="comment"]');
      if (commentBtn) {
        commentBtn.click();
      }

      // Wait for comment box to appear, then insert text
      setTimeout(() => {
        const commentBox = post.querySelector('.ql-editor, .comments-comment-texteditor__content, [contenteditable="true"]') ||
                          document.querySelector('.ql-editor, .comments-comment-texteditor__content, [contenteditable="true"]');
        
        if (commentBox) {
          commentBox.focus();
          // Use textContent for security - avoid innerHTML with untrusted content
          const p = document.createElement('p');
          p.textContent = text;
          commentBox.innerHTML = '';
          commentBox.appendChild(p);
          
          // Trigger input event
          const inputEvent = new Event('input', { bubbles: true });
          commentBox.dispatchEvent(inputEvent);
        }
      }, 500);
    }

    this.closeEngagePanel();
  }

  closeEngagePanel() {
    if (this.currentPanel) {
      this.currentPanel.remove();
      this.currentPanel = null;
    }
    // Don't clear currentInputField here - we need it for the delayed insert
    document.removeEventListener('click', this.handleOutsideClick.bind(this));
  }
  
  clearCurrentInputField() {
    this.currentInputField = null;
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => new LinkedInEngageAI());
} else {
  new LinkedInEngageAI();
}
