/**
 * LinkedIn Engage AI - Popup Script
 */

// Firebase config inlined to avoid ES module import issues
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyB3grbdy16Z_Tqr7m4PCKyHjK1jzjGnKnc",
  projectId: "linkedinengageai-d869c"
};

const FIRESTORE_BASE_URL = `https://firestore.googleapis.com/v1/projects/${FIREBASE_CONFIG.projectId}/databases/linkedinengageai/documents`;

const AUTH_STORAGE_KEY = 'linkedin_engage_auth';

const ADMIN_EMAIL = 'cmuthya001@gmail.com';

// Subscription constants
const SUBSCRIPTION_CONFIG = {
  FREE_TOKENS: 20,
  PREMIUM_PRICE: 5,
};

const ACCOUNT_TYPE = {
  BASIC: 'basic',
  PREMIUM: 'premium',
};

// Local token tracking for immediate UI updates
let localTokenCount = null;
let currentUserId = null;
let subscriptionRefreshInterval = null;
const REFRESH_INTERVAL_MS = 10000; // Refresh subscription every 10 seconds

// Inlined Firestore helper functions
function buildFirestoreUrl(path) {
  const separator = path.includes('?') ? '&' : '?';
  return `${path}${separator}key=${FIREBASE_CONFIG.apiKey}`;
}

async function getUserFromFirestore(userId) {
  const url = buildFirestoreUrl(`${FIRESTORE_BASE_URL}/users/${userId}`);
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });
    if (response.status === 404) return null;
    if (!response.ok) {
      const errorData = await response.json();
      if (errorData.error?.status === 'NOT_FOUND' || errorData.error?.code === 404) return null;
      throw new Error(`Firestore get failed: ${errorData.error?.message || response.statusText}`);
    }
    return await response.json();
  } catch (error) {
    if (error.message.includes('NOT_FOUND') || error.message.includes('not found')) return null;
    console.error('[Firestore] Error getting user:', error);
    throw error;
  }
}

async function saveUserToFirestore(userData) {
  const { id, email, name, picture } = userData;
  const now = new Date().toISOString();
  const extensionVersion = chrome.runtime.getManifest().version;
  
  try {
    const existingUser = await getUserFromFirestore(id);
    
    if (existingUser) {
      // User exists - update signInTime and lastActiveTime
      console.log('[Firestore] User exists, updating sign-in info:', id);
      
      // Build update data
      const updateFields = {
        signInTime: { timestampValue: now },
        lastActiveTime: { timestampValue: now }
      };
      const updateMask = ['signInTime', 'lastActiveTime'];
      
      // Check if existingUser has fields property (Firestore format)
      const fields = existingUser.fields || existingUser;
      
      // Add tokensRemaining if missing
      if (!fields.tokensRemaining) {
        updateFields.tokensRemaining = { integerValue: String(SUBSCRIPTION_CONFIG.FREE_TOKENS) };
        updateMask.push('tokensRemaining');
        console.log('[Firestore] Adding missing tokensRemaining to user:', id);
      }
      
      // Add accountType if missing
      if (!fields.accountType) {
        updateFields.accountType = { stringValue: ACCOUNT_TYPE.BASIC };
        updateMask.push('accountType');
        console.log('[Firestore] Adding missing accountType to user:', id);
      }
      
      // Add tokensUsed if missing
      if (!fields.tokensUsed) {
        updateFields.tokensUsed = { integerValue: '0' };
        updateMask.push('tokensUsed');
        console.log('[Firestore] Adding missing tokensUsed to user:', id);
      }
      
      // Add subscriptionStatus if missing
      if (!fields.subscriptionStatus) {
        updateFields.subscriptionStatus = { stringValue: 'inactive' };
        updateMask.push('subscriptionStatus');
        console.log('[Firestore] Adding missing subscriptionStatus to user:', id);
      }
      
      // Update user document
      const updateUrl = buildFirestoreUrl(`${FIRESTORE_BASE_URL}/users/${id}?${updateMask.map(f => `updateMask.fieldPaths=${f}`).join('&')}`);
      const updateResponse = await fetch(updateUrl, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: updateFields })
      });
      
      if (!updateResponse.ok) {
        const errorData = await updateResponse.json();
        console.error('[Firestore] Update failed:', errorData);
      } else {
        console.log('[Firestore] User sign-in info updated successfully:', id);
      }
      
      return existingUser;
    }
    
    // Create new user document
    const userDocument = {
      fields: {
        uid: { stringValue: id },
        email: { stringValue: email || '' },
        displayName: { stringValue: name || '' },
        photoURL: { stringValue: picture || '' },
        signInTime: { timestampValue: now },
        lastActiveTime: { timestampValue: now },
        createdAt: { timestampValue: now },
        platform: { stringValue: 'chrome_extension' },
        extensionVersion: { stringValue: extensionVersion },
        accountType: { stringValue: ACCOUNT_TYPE.BASIC },
        tokensRemaining: { integerValue: String(SUBSCRIPTION_CONFIG.FREE_TOKENS) },
        tokensUsed: { integerValue: '0' },
        subscriptionStatus: { stringValue: 'inactive' }
      }
    };
    const url = buildFirestoreUrl(`${FIRESTORE_BASE_URL}/users?documentId=${id}`);
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userDocument)
    });
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Firestore save failed: ${errorData.error?.message || response.statusText}`);
    }
    console.log('[Firestore] New user saved successfully:', id);
    return await response.json();
  } catch (error) {
    console.error('[Firestore] Error saving user:', error);
    throw error;
  }
}

// Subscription helper functions - reads from users collection only

async function getSubscriptionFromUser(userId) {
  const url = buildFirestoreUrl(`${FIRESTORE_BASE_URL}/users/${userId}`);
  console.log('[Popup] Fetching subscription from users:', url);
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });
    console.log('[Popup] User fetch response status:', response.status);
    if (response.status === 404) {
      console.log('[Popup] User not found (404)');
      return null;
    }
    if (!response.ok) {
      const errorData = await response.json();
      console.error('[Popup] User fetch error:', errorData);
      if (errorData.error?.status === 'NOT_FOUND' || errorData.error?.code === 404) return null;
      throw new Error(`User get failed: ${errorData.error?.message || response.statusText}`);
    }
    const result = await response.json();
    console.log('[Popup] Raw user data:', JSON.stringify(result));
    return parseUserSubscription(result);
  } catch (error) {
    if (error.message.includes('NOT_FOUND') || error.message.includes('not found')) return null;
    console.error('[Popup] Error getting user subscription:', error);
    return null;
  }
}

function parseUserSubscription(doc) {
  console.log('[Popup] parseUserSubscription input:', JSON.stringify(doc));
  if (!doc || !doc.fields) {
    console.log('[Popup] parseUserSubscription: no doc or no fields');
    return null;
  }
  const fields = doc.fields;
  
  // Parse tokensRemaining - return ACTUAL value from Firebase, null if missing
  // Do NOT default to 20 here - that would reset existing users' tokens!
  let tokensRemaining = null;
  if (fields.tokensRemaining?.integerValue !== undefined) {
    tokensRemaining = parseInt(fields.tokensRemaining.integerValue, 10);
  }
  
  const parsed = {
    accountType: fields.accountType?.stringValue || ACCOUNT_TYPE.BASIC,
    tokensRemaining: tokensRemaining,
    tokensUsed: parseInt(fields.tokensUsed?.integerValue || '0', 10),
    subscriptionStatus: fields.subscriptionStatus?.stringValue || 'inactive',
    subscriptionStartDate: fields.subscriptionStartDate?.timestampValue || null,
    subscriptionRenewalDate: fields.subscriptionRenewalDate?.timestampValue || null,
    hasTokensField: fields.tokensRemaining !== undefined,
  };
  console.log('[Popup] Parsed subscription from user:', parsed);
  return parsed;
}

async function getOrCreateSubscription(userId) {
  const subscription = await getSubscriptionFromUser(userId);
  if (!subscription) {
    // User not found in Firebase - return null, don't create fake default values
    console.log('[Popup] No subscription found for user:', userId);
    return null;
  }
  // Return actual Firebase values - tokensRemaining could be null if field missing
  return subscription;
}

document.addEventListener('DOMContentLoaded', () => {
  initPopup();
});

async function initPopup() {
  // Set version from manifest
  const versionElement = document.getElementById('extensionVersion');
  if (versionElement) {
    versionElement.textContent = `v${chrome.runtime.getManifest().version}`;
  }
  
  await checkAuthState();
}

async function checkAuthState() {
  const signInSection = document.getElementById('signInSection');
  const mainContent = document.getElementById('mainContent');
  
  try {
    const result = await chrome.storage.local.get([AUTH_STORAGE_KEY]);
    const authData = result[AUTH_STORAGE_KEY];
    
    if (authData && authData.user) {
      // User has signed in before - trust the stored data
      // Don't verify token here - it may have expired but we can refresh it
      currentUserId = authData.user.id;
      showAuthenticatedUI(authData.user);
      await checkApiKeyStatus();
      await loadStats();
      setupEventListeners();
      
      // Start periodic subscription refresh
      startSubscriptionRefresh(authData.user.id);
      
      // Listen for token update messages from background
      setupTokenUpdateListener();
      
      // Silently refresh token in background (don't block UI)
      refreshTokenInBackground();
      return;
    }

    // User is not authenticated - show sign in UI and setup listeners
    showSignInUI();
    setupSignInListeners();
    
  } catch (error) {
    console.error('Auth check error:', error);
    showSignInUI();
    setupSignInListeners();
  }
}

// Silently refresh token in background without affecting UI
async function refreshTokenInBackground() {
  try {
    const token = await new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive: false }, (authToken) => {
        if (chrome.runtime.lastError || !authToken) {
          reject(new Error('Token refresh failed'));
        } else {
          resolve(authToken);
        }
      });
    });
    
    // Update stored token
    const result = await chrome.storage.local.get([AUTH_STORAGE_KEY]);
    if (result[AUTH_STORAGE_KEY]) {
      result[AUTH_STORAGE_KEY].token = token;
      await chrome.storage.local.set({ [AUTH_STORAGE_KEY]: result[AUTH_STORAGE_KEY] });
      console.log('[Auth] Token refreshed in background');
    }
  } catch (error) {
    // Silent fail - don't log out user, token will be refreshed on next action
    console.log('[Auth] Background token refresh skipped');
  }
}

async function verifyToken(token) {
  try {
    const response = await fetch(`https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=${token}`);
    return response.ok;
  } catch (error) {
    return false;
  }
}

function showSignInUI() {
  document.getElementById('signInSection').style.display = 'flex';
  document.getElementById('mainContent').style.display = 'none';
}

async function showAuthenticatedUI(user) {
  console.log('[Popup] showAuthenticatedUI called with user:', JSON.stringify(user));
  document.getElementById('signInSection').style.display = 'none';
  document.getElementById('mainContent').style.display = 'block';
  
  // Update user info
  const userAvatar = document.getElementById('userAvatar');
  const userName = document.getElementById('userName');
  const userEmail = document.getElementById('userEmail');
  
  if (user.picture) {
    userAvatar.src = user.picture;
    userAvatar.style.display = 'block';
  } else {
    userAvatar.style.display = 'none';
  }
  
  userName.textContent = user.name || 'User';
  userEmail.textContent = user.email || '';
  
  // Load and display subscription status
  console.log('[Popup] Calling loadSubscriptionStatus with userId:', user.id);
  await loadSubscriptionStatus(user.id);

  // Check if user is admin and show/hide admin-only elements
  const isAdmin = user.email === ADMIN_EMAIL;
  const settingsBtn = document.getElementById('openOptions');
  const apiKeyWarning = document.getElementById('apiKeyWarning');
  
  if (settingsBtn) {
    settingsBtn.style.display = isAdmin ? 'flex' : 'none';
  }
  
  // Store admin status for later use
  window.isAdminUser = isAdmin;
}

async function loadSubscriptionStatus(userId) {
  const tokensDisplay = document.getElementById('tokensDisplay');
  
  // Validate userId
  if (!userId) {
    console.error('[Popup] No userId provided to loadSubscriptionStatus');
    if (tokensDisplay) {
      tokensDisplay.innerHTML = `<span class="token-count">${SUBSCRIPTION_CONFIG.FREE_TOKENS}</span> / ${SUBSCRIPTION_CONFIG.FREE_TOKENS} tokens`;
    }
    return;
  }
  
  try {
    console.log('[Popup] Loading subscription for user:', userId);
    const subscription = await getOrCreateSubscription(userId);
    console.log('[Popup] Subscription loaded:', JSON.stringify(subscription));
    
    if (!subscription) {
      console.error('[Popup] getOrCreateSubscription returned null/undefined');
      if (tokensDisplay) {
        tokensDisplay.innerHTML = `<span class="token-count">${SUBSCRIPTION_CONFIG.FREE_TOKENS}</span> / ${SUBSCRIPTION_CONFIG.FREE_TOKENS} tokens`;
      }
      return;
    }
    
    const subscriptionSection = document.getElementById('subscriptionSection');
    const accountTypeBadge = document.getElementById('accountTypeBadge');
    const upgradeSection = document.getElementById('upgradeSection');
    
    if (!subscriptionSection) return;
    
    const isPremium = subscription.accountType === ACCOUNT_TYPE.PREMIUM && 
                      subscription.subscriptionStatus === 'active';
    
    // Update account type badge
    if (accountTypeBadge) {
      accountTypeBadge.textContent = isPremium ? '⭐ Premium' : 'Basic';
      accountTypeBadge.className = `account-badge ${isPremium ? 'premium' : 'basic'}`;
    }
    
    // Update tokens display (only for basic users)
    if (tokensDisplay) {
      if (isPremium) {
        tokensDisplay.innerHTML = '<span class="unlimited">Unlimited</span>';
      } else {
        // Use actual Firebase value - if null/undefined, show error state, don't default to 20
        const tokensLeft = subscription.tokensRemaining;
        if (tokensLeft === null || tokensLeft === undefined) {
          console.warn('[Popup] tokensRemaining is missing from Firebase for user:', userId);
          tokensDisplay.innerHTML = `<span class="token-count">--</span> / ${SUBSCRIPTION_CONFIG.FREE_TOKENS} tokens`;
        } else {
          console.log('[Popup] Updating token display with:', tokensLeft);
          tokensDisplay.innerHTML = `<span class="token-count">${tokensLeft}</span> / ${SUBSCRIPTION_CONFIG.FREE_TOKENS} tokens`;
          
          // Add warning styling if low
          if (tokensLeft <= 5) {
            tokensDisplay.classList.add('low-tokens');
          } else {
            tokensDisplay.classList.remove('low-tokens');
          }
        }
      }
    }
    
    // Show/hide upgrade section
    if (upgradeSection) {
      if (isPremium) {
        upgradeSection.style.display = 'none';
      } else if (subscription.tokensRemaining !== null && subscription.tokensRemaining <= 5) {
        upgradeSection.style.display = 'block';
      } else {
        upgradeSection.style.display = 'none';
      }
    }
    
    // Store subscription for later use
    window.currentSubscription = subscription;
    // Update local token count
    localTokenCount = subscription.tokensRemaining;
    
  } catch (error) {
    console.error('[Subscription] Error loading status:', error);
    // Show fallback UI on error
    if (tokensDisplay) {
      tokensDisplay.innerHTML = `<span class="token-count error">Error</span>`;
    }
  }
}

/**
 * Start periodic subscription refresh from Firebase
 */
function startSubscriptionRefresh(userId) {
  // Clear any existing interval
  if (subscriptionRefreshInterval) {
    clearInterval(subscriptionRefreshInterval);
  }
  
  // Set up periodic refresh
  subscriptionRefreshInterval = setInterval(async () => {
    try {
      console.log('[Popup] Refreshing subscription from Firebase...');
      await loadSubscriptionStatus(userId);
    } catch (error) {
      console.error('[Popup] Failed to refresh subscription:', error);
    }
  }, REFRESH_INTERVAL_MS);
  
  console.log('[Popup] Started subscription refresh interval');
}

/**
 * Stop subscription refresh (call when popup closes or user signs out)
 */
function stopSubscriptionRefresh() {
  if (subscriptionRefreshInterval) {
    clearInterval(subscriptionRefreshInterval);
    subscriptionRefreshInterval = null;
    console.log('[Popup] Stopped subscription refresh interval');
  }
}

/**
 * Listen for token update messages from background script
 */
function setupTokenUpdateListener() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'TOKEN_CONSUMED') {
      console.log('[Popup] Received token consumed notification:', message.tokensRemaining);
      // Update local token count immediately
      localTokenCount = message.tokensRemaining;
      updateTokenDisplayImmediate(message.tokensRemaining);
      sendResponse({ received: true });
    }
    return true;
  });
}

/**
 * Update token display immediately (for local updates before Firebase sync)
 */
function updateTokenDisplayImmediate(tokensRemaining) {
  const tokensDisplay = document.getElementById('tokensDisplay');
  const upgradeSection = document.getElementById('upgradeSection');
  
  if (tokensDisplay) {
    tokensDisplay.innerHTML = `<span class="token-count">${tokensRemaining}</span> / ${SUBSCRIPTION_CONFIG.FREE_TOKENS} tokens`;
    
    if (tokensRemaining <= 5) {
      tokensDisplay.classList.add('low-tokens');
    } else {
      tokensDisplay.classList.remove('low-tokens');
    }
  }
  
  if (upgradeSection) {
    if (tokensRemaining <= 5) {
      upgradeSection.style.display = 'block';
    }
  }
  
  // Update stored subscription
  if (window.currentSubscription) {
    window.currentSubscription.tokensRemaining = tokensRemaining;
  }
}

function setupSignInListeners() {
  const signInBtn = document.getElementById('googleSignInBtn');
  if (signInBtn) {
    // Remove any existing listener first to prevent duplicates
    signInBtn.removeEventListener('click', handleGoogleSignIn);
    signInBtn.addEventListener('click', handleGoogleSignIn);
  }
}

async function handleGoogleSignIn() {
  const signInBtn = document.getElementById('googleSignInBtn');
  signInBtn.disabled = true;
  signInBtn.innerHTML = '<span>Signing in...</span>';
  
  try {
    // Simple OAuth2 flow - let Chrome handle token caching
    const token = await new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive: true }, (authToken) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (!authToken) {
          reject(new Error('No token received'));
        } else {
          resolve(authToken);
        }
      });
    });
    
    console.log('[Auth] Got token successfully');

    console.log('[Auth] Fetching user info...');
    
    // Fetch user info from Google
    const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!userInfoResponse.ok) {
      throw new Error('Failed to fetch user information');
    }

    const userInfo = await userInfoResponse.json();
    console.log('[Auth] User info received:', userInfo.email);

    // Store auth data
    const authData = {
      token,
      user: {
        id: userInfo.id,
        email: userInfo.email,
        name: userInfo.name,
        picture: userInfo.picture
      },
      signedInAt: Date.now()
    };

    await chrome.storage.local.set({ [AUTH_STORAGE_KEY]: authData });
    console.log('[Auth] Auth data stored');
    

    // Save user data to Firestore
    try {
      await saveUserToFirestore(authData.user);
      console.log('[Auth] User data saved to Firestore successfully');
    } catch (firestoreError) {
      console.error('[Auth] Failed to save user data to Firestore:', firestoreError);
      // Don't block sign-in if Firestore save fails
    }
    
    // Notify background script of sign in
    try {
      await chrome.runtime.sendMessage({ type: 'AUTH_STATE_CHANGED', isAuthenticated: true });
    } catch (e) {
      console.log('[Auth] Could not notify background script');
    }

    // Show authenticated UI
    showAuthenticatedUI(authData.user);
    await checkApiKeyStatus();
    await loadStats();
    setupEventListeners();
    
    console.log('[Auth] Sign-in complete!');

  } catch (error) {
    console.error('Sign in error:', error);
    signInBtn.disabled = false;
    signInBtn.innerHTML = `
      <svg class="google-icon" viewBox="0 0 24 24" width="18" height="18">
        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
      </svg>
      <span>Sign in with Google</span>
    `;
    alert('Sign in failed: ' + error.message);
  }
}

async function handleSignOut() {
  try {
    const result = await chrome.storage.local.get([AUTH_STORAGE_KEY]);
    const authData = result[AUTH_STORAGE_KEY];

    if (authData?.token) {
      // Just remove the specific cached token - simple and reliable
      await new Promise((resolve) => {
        chrome.identity.removeCachedAuthToken({ token: authData.token }, resolve);
      });
    }

    // Clear stored auth data
    await chrome.storage.local.remove([AUTH_STORAGE_KEY]);
    
    // Notify background script of sign out
    try {
      await chrome.runtime.sendMessage({ type: 'AUTH_STATE_CHANGED', isAuthenticated: false });
    } catch (e) {
      // Ignore if background script not available
    }

    // Show sign in UI immediately
    const signInSection = document.getElementById('signInSection');
    const mainContent = document.getElementById('mainContent');
    
    if (signInSection) signInSection.style.display = 'flex';
    if (mainContent) mainContent.style.display = 'none';
    

    // Reset and re-setup sign in button
    const signInBtn = document.getElementById('googleSignInBtn');
    if (signInBtn) {
      signInBtn.disabled = false;
      signInBtn.innerHTML = `
        <svg class="google-icon" viewBox="0 0 24 24" width="18" height="18">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        <span>Sign in with Google</span>
      `;
    }
    
    // Setup sign-in listeners (removes existing listener first to prevent duplicates)
    setupSignInListeners();

  } catch (error) {
    console.error('Sign out error:', error);
    // Still try to show sign in UI even if there was an error
    const signInSection = document.getElementById('signInSection');
    const mainContent = document.getElementById('mainContent');
    if (signInSection) signInSection.style.display = 'flex';
    if (mainContent) mainContent.style.display = 'none';
    

    // Reset button even on error
    const signInBtn = document.getElementById('googleSignInBtn');
    if (signInBtn) {
      signInBtn.disabled = false;
      signInBtn.innerHTML = `
        <svg class="google-icon" viewBox="0 0 24 24" width="18" height="18">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        <span>Sign in with Google</span>
      `;
    }
    // Re-setup listeners
    setupSignInListeners();
  }
}

async function checkApiKeyStatus() {
  const statusIndicator = document.getElementById('statusIndicator');
  const statusDot = statusIndicator.querySelector('.status-dot');
  const statusText = statusIndicator.querySelector('.status-text');
  const apiKeyWarning = document.getElementById('apiKeyWarning');

  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_API_KEY_STATUS' });
    
    if (response.hasApiKey) {
      statusDot.classList.add('active');
      statusDot.classList.remove('error');
      statusText.textContent = 'Ready to engage!';
      apiKeyWarning.style.display = 'none';
    } else {
      statusDot.classList.add('error');
      statusDot.classList.remove('active');

      // Only show API key warning and status for admin users
      if (window.isAdminUser) {
        statusText.textContent = 'API key not configured';
        apiKeyWarning.style.display = 'block';
      } else {
        statusText.textContent = 'Ready to engage!';
        statusDot.classList.remove('error');
        statusDot.classList.add('active');
        apiKeyWarning.style.display = 'none';
      }
    }
  } catch (error) {
    statusDot.classList.add('error');
    statusText.textContent = 'Error checking status';
    console.error('Status check error:', error);
  }
}

async function loadStats() {
  try {
    const result = await chrome.storage.local.get(['stats']);
    const stats = result.stats || { generated: 0, inserted: 0, tones: {} };

    document.getElementById('totalGenerated').textContent = stats.generated || 0;
    document.getElementById('totalInserted').textContent = stats.inserted || 0;

    // Find favorite tone
    if (stats.tones && Object.keys(stats.tones).length > 0) {
      const favoriteTone = Object.entries(stats.tones)
        .sort((a, b) => b[1] - a[1])[0][0];
      document.getElementById('favoriteTone').textContent = formatToneName(favoriteTone);
    }
  } catch (error) {
    console.error('Failed to load stats:', error);
  }
}

function formatToneName(tone) {
  const toneNames = {
    'lighthearted': 'Light',
    'reply_comment': 'Reply',
    'dm': 'DM',
    'support': 'Support',
    'add_opinion': 'Opinion',
    'ask_question': 'Ask',
    'answer_question': 'Answer',
    'share_resources': 'Share',
    'make_intro': 'Intro',
    'custom': 'Custom'
  };
  return toneNames[tone] || tone;
}

function setupEventListeners() {
  // Sign out button
  document.getElementById('signOutBtn')?.addEventListener('click', handleSignOut);
  
  // Open LinkedIn button
  document.getElementById('openLinkedIn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.linkedin.com/feed/' });
  });

  // Open Options button
  document.getElementById('openOptions').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // Setup API Key button
  document.getElementById('setupApiKey')?.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // Upgrade button - opens payment page
  document.getElementById('upgradeBtn')?.addEventListener('click', handleUpgradeClick);

  // Help link
  document.getElementById('helpLink').addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'https://github.com/linkedin-engage-ai/help' });
  });

  // Feedback link
  document.getElementById('feedbackLink').addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'https://github.com/linkedin-engage-ai/feedback' });
  });
}

async function handleUpgradeClick() {
  // For now, show a message that premium upgrades are coming soon
  // TODO: Integrate with Stripe or payment provider
  const upgradeBtn = document.getElementById('upgradeBtn');
  if (upgradeBtn) {
    upgradeBtn.textContent = 'Coming Soon!';
    upgradeBtn.disabled = true;
    setTimeout(() => {
      upgradeBtn.textContent = 'Upgrade Now';
      upgradeBtn.disabled = false;
    }, 2000);
  }
  
  // Alternatively, you could open a payment page when ready:
  // chrome.tabs.create({ url: 'https://your-payment-page.com/upgrade' });
}
