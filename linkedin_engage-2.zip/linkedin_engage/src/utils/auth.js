/**
 * LinkedIn Engage AI - Google Authentication Module
 * Handles Google Sign-In for extension access control
 */

const AUTH_STORAGE_KEY = 'linkedin_engage_auth';

/**
 * Get current authentication state
 * @returns {Promise<{isAuthenticated: boolean, user: object|null}>}
 */
export async function getAuthState() {
  try {
    const result = await chrome.storage.local.get([AUTH_STORAGE_KEY]);
    const authData = result[AUTH_STORAGE_KEY];
    
    if (authData && authData.token && authData.user) {
      // Verify token is still valid
      const isValid = await verifyToken(authData.token);
      if (isValid) {
        return { isAuthenticated: true, user: authData.user };
      }
    }
    
    return { isAuthenticated: false, user: null };
  } catch (error) {
    console.error('Error getting auth state:', error);
    return { isAuthenticated: false, user: null };
  }
}

/**
 * Sign in with Google
 * @returns {Promise<{success: boolean, user: object|null, error: string|null}>}
 */
export async function signInWithGoogle() {
  try {
    // Use Chrome Identity API for OAuth2
    const token = await new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive: true }, (token) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(token);
        }
      });
    });

    if (!token) {
      return { success: false, user: null, error: 'Failed to get authentication token' };
    }

    // Fetch user info from Google
    const userInfo = await fetchGoogleUserInfo(token);
    
    if (!userInfo) {
      return { success: false, user: null, error: 'Failed to fetch user information' };
    }

    // Store auth data
    const authData = {
      token,
      user: {
        id: userInfo.id,
        email: userInfo.email,
        name: userInfo.name,
        picture: userInfo.picture
      },
      signedInAt: Date.now()
    };

    await chrome.storage.local.set({ [AUTH_STORAGE_KEY]: authData });

    return { success: true, user: authData.user, error: null };
  } catch (error) {
    console.error('Sign in error:', error);
    return { success: false, user: null, error: error.message };
  }
}

/**
 * Sign out
 * @returns {Promise<{success: boolean}>}
 */
export async function signOut() {
  try {
    // Get current token to revoke
    const result = await chrome.storage.local.get([AUTH_STORAGE_KEY]);
    const authData = result[AUTH_STORAGE_KEY];

    if (authData?.token) {
      // Revoke the token
      await new Promise((resolve) => {
        chrome.identity.removeCachedAuthToken({ token: authData.token }, resolve);
      });
    }

    // Clear stored auth data
    await chrome.storage.local.remove([AUTH_STORAGE_KEY]);

    return { success: true };
  } catch (error) {
    console.error('Sign out error:', error);
    // Still clear local data even if revoke fails
    await chrome.storage.local.remove([AUTH_STORAGE_KEY]);
    return { success: true };
  }
}

/**
 * Fetch user info from Google API
 * @param {string} token - OAuth2 access token
 * @returns {Promise<object|null>}
 */
async function fetchGoogleUserInfo(token) {
  try {
    const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch user info');
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching user info:', error);
    return null;
  }
}

/**
 * Verify if token is still valid
 * @param {string} token - OAuth2 access token
 * @returns {Promise<boolean>}
 */
async function verifyToken(token) {
  try {
    const response = await fetch(`https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=${token}`);
    return response.ok;
  } catch (error) {
    return false;
  }
}

/**
 * Check if user is authenticated (simple check)
 * @returns {Promise<boolean>}
 */
export async function isAuthenticated() {
  const { isAuthenticated } = await getAuthState();
  return isAuthenticated;
}
